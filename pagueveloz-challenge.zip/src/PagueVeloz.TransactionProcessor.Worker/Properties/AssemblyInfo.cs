using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("PagueVeloz.TransactionProcessor.IntegrationTests")]
