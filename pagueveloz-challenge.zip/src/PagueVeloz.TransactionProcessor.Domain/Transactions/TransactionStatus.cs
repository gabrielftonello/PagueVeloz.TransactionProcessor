namespace PagueVeloz.TransactionProcessor.Domain.Transactions;

public enum TransactionStatus
{
  Success = 1,
  Failed = 2,
  Pending = 3
}
