namespace PagueVeloz.TransactionProcessor.Domain.Accounts;

public enum AccountStatus
{
  Active = 1,
  Inactive = 2,
  Blocked = 3
}
