public partial class Program { }
